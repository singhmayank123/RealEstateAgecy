import java.util.ArrayList; //to import ArrayList class
import java.util.Scanner; //to import Scanner class
// Main Class which operates all other classes
public class ManagementSystem{

		static int bedrooms,bathrooms,yearBuilt; //Residence data fields
		static int housingUnit, floor, parkingLotNumber; //apartment data fields
		static int garage,stories; //House data fields
	    static boolean isBasement, isBackyard; // House data fields
		static double price,squareFeet; //Residence data fields
		static String address; //Residence data fields
		

//Main method from where compiler starts to execute the LOC one by one
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in); //Creating instance of Scanner Class

		ArrayList<House>houses = new ArrayList<House>(); //for storing House objects
		ArrayList<Apartment>apartments = new ArrayList<Apartment>(); //for storing Aparment objects
        
		
		int houseIndex = 0,apartmentIndex = 0; //index data fields
		//this loop iterates until the user enter exit or ctrl+C on console screen.
        while(true){

        int choice = menu(); //calling and display menu items

		if(choice == 1){
     /*this method display data members of Residence Class, this method helps in code  reusability
		because if we don't call this method then we have to write entire LOCs of this method two 
		times:for House and Apartment */
                takeResidentialFields(); 
        //Taking user inputs with the help of scanner object
                System.out.print("Enter no. of garage: ");
                garage = sc.nextInt(); //integer value
                System.out.print("Enter no. of stories: ");
                stories = sc.nextInt();
                System.out.print("Is there any Basement?(y/n) : ");
                if(sc.next().equals("y")) isBasement = true;
                else isBasement = false;
                System.out.print("Is there any BackYard?(y/n) : ");
                if(sc.next().equals("y")) isBackyard = true;
                else isBackyard = false;
        //Adding an object of House class by invoking parameterized constructor   
				houses.add(new House(garage,stories,isBasement,isBackyard,
					bedrooms,bathrooms,yearBuilt,price,squareFeet,address));
			}
		else if(choice == 2){
        // This satisfies when user choose apartment, So all the same things happen again
				takeResidentialFields();
                System.out.print("Enter housing units: ");
                housingUnit = sc.nextInt();
                System.out.print("Enter No. of floors: ");
                floor = sc.nextInt();
                System.out.print("Enter parkingLotNumber: ");
                parkingLotNumber = sc.nextInt();
        //Adding an object of Apartment class by invoking parameterized constructor  
				apartments.add(new Apartment(housingUnit,floor,parkingLotNumber,
					bedrooms,bathrooms,yearBuilt,price,squareFeet,address));

			}
		else if(choice == 3){
         //Displays all house data fields      
                if(houses.isEmpty()){
                	System.out.print("\nNo records found!!\n ");
                }
                else{

                	for(int i = 0; i<houses.size(); i++){
//printing the return value by calling toString function of House class
                		System.out.println(houses.get(i).toString());
                	}
                }
			
			}
		else if(choice == 4){
			 //Displays all house data fields 
				if(apartments.isEmpty()){
	                	System.out.print("\nNo records found!!\n ");
	                }
	                else{
//printing the return value by calling toString function of House class
	                	for(int i = 0; i<apartments.size(); i++){
	                		System.out.println(apartments.get(i).toString());
	                	}
	                }

		}
		else if(choice == 5){
//Updates the data field of House objects
			System.out.printf("\nYou have total %d House records!\n",houses.size());
			System.out.print("Which record you want to update?? ");
			int changeRec = sc.nextInt();
//Displaying menus
			System.out.println("\nAvailable fields in you house!\n");
			updateResidentialFields(); //helps in code re-usability
			System.out.println("\nEnter 7: to update garages");
			System.out.println("Enter 8: to update stories");
			System.out.println("Enter 9: to update Basement Availability");
			System.out.println("Enter 10: to update BackYard Availability");

			System.out.print("Enter your choice: ");

			int res = sc.nextInt(); 

			if(res == 1){
				System.out.print("\nEnter new value: ");
				bedrooms = sc.nextInt();
				houses.get(changeRec-1).setBedrooms(bedrooms);
				System.out.println("\nUpdated Successfully! ");
			}
			else if(res == 2){
				System.out.print("\nEnter new value: ");
				bathrooms = sc.nextInt();
				houses.get(changeRec-1).setBathrooms(bathrooms);
				System.out.println("\nUpdated Successfully! ");
			}
			else if(res == 3){
				System.out.print("\nEnter new value: ");
				yearBuilt = sc.nextInt();
				houses.get(changeRec-1).setYearBuilt(yearBuilt);
				System.out.println("\nUpdated Successfully! ");
			}
			else if(res == 4){
				System.out.print("\nEnter new value: ");
				price = sc.nextInt();
				houses.get(changeRec-1).setPrice(price);
				System.out.println("\nUpdated Successfully! ");
			}
			else if(res == 5){
				System.out.print("\nEnter new value: ");
				squareFeet = sc.nextInt();
				houses.get(changeRec-1).setSquareFeet(squareFeet);
				System.out.println("\nUpdated Successfully! ");
			}
			else if(res == 6){
				System.out.print("\nEnter new value: ");
				sc.nextLine();
				address = sc.nextLine();
				houses.get(changeRec-1).setAddress(address);
				System.out.println("\nUpdated Successfully! ");
			}

			else if(res == 7){
				System.out.print("\nEnter new value: ");
				garage = sc.nextInt();
				houses.get(changeRec-1).setGarage(garage);
				System.out.println("\nUpdated Successfully! ");
			}
			else if(res == 8){
				System.out.print("\nEnter new value: ");
				stories = sc.nextInt();
				houses.get(changeRec-1).setStories(stories);
				System.out.println("\nUpdated Successfully! ");
			}
			else if(res == 9){
				System.out.print("\nEnter new value: ");
				isBasement = sc.nextBoolean();
				houses.get(changeRec-1).setBasement(isBasement);
				System.out.println("\nUpdated Successfully! ");
			}
			else if(res == 10){
				System.out.print("\nEnter new value: ");
				isBackyard = sc.nextBoolean();
				houses.get(changeRec-1).setBackyard(isBackyard);
				System.out.println("\nUpdated Successfully! ");
			}
			else {
				
				System.out.println("\nInvalid Response!");
			}

			
		}
		else if(choice == 6){

				System.out.printf("\nYou have total %d apartments records!\n",apartments.size());
				System.out.print("\nWhich record you want to update?? ");
				int changeRec = sc.nextInt();

				System.out.println("\nBelow are the available fields in you apartments!\n");
				updateResidentialFields();
				System.out.println("\nEnter 7: to housing units");
				System.out.println("Enter 8: to update floors");
				System.out.println("Enter 9: to update parkingLotNumber");

				System.out.print("Enter your choice: "); 

				int res = sc.nextInt(); 

				if(res == 1){
					System.out.print("\nEnter new value: ");
					bedrooms = sc.nextInt();
					apartments.get(changeRec-1).setBedrooms(bedrooms);
					System.out.println("\nUpdated Successfully! ");
				}
				else if(res == 2){
					System.out.print("\nEnter new value: ");
					bathrooms = sc.nextInt();
					apartments.get(changeRec-1).setBathrooms(bathrooms);
					System.out.println("\nUpdated Successfully! ");
				}
				else if(res == 3){
					System.out.print("\nEnter new value: ");
					yearBuilt = sc.nextInt();
					apartments.get(changeRec-1).setYearBuilt(yearBuilt);
					System.out.println("\nUpdated Successfully! ");
				}
				else if(res == 4){
					System.out.print("\nEnter new value: ");
					price = sc.nextInt();
					apartments.get(changeRec-1).setPrice(price);
					System.out.println("\nUpdated Successfully! ");
				}
				else if(res == 5){
					System.out.print("\nEnter new value: ");
					squareFeet = sc.nextInt();
					apartments.get(changeRec-1).setSquareFeet(squareFeet);
					System.out.println("\nUpdated Successfully! ");
				}
				else if(res == 6){
					System.out.print("\nEnter new value: ");
					sc.nextLine();
					address = sc.nextLine();
					apartments.get(changeRec-1).setAddress(address);
					System.out.println("\nUpdated Successfully! ");
				}

				else if(res == 7){
					System.out.print("\nEnter new value: ");
					housingUnit = sc.nextInt();
					apartments.get(changeRec-1).setUnit(housingUnit);
					System.out.println("\nUpdated Successfully! ");
				}
				else if(res == 8){
					System.out.print("\nEnter new value: ");
					floor = sc.nextInt();
					apartments.get(changeRec-1).setFLoor(floor);
					System.out.println("\nUpdated Successfully! ");
				}
				else if(res == 9){
					System.out.print("\nEnter new value: ");
					parkingLotNumber = sc.nextInt();
					apartments.get(changeRec-1).setParkingNumber(parkingLotNumber);
					System.out.println("\nUpdated Successfully! ");
				}
				
		}
		else if(choice == 7){
			System.out.println("\nThank you!");
			break;
		}
		else{
			System.out.println("\nInvalid Choice!");
			}
    	}
		
	}

	public static int menu(){

		Scanner sc = new Scanner(System.in);
       
		System.out.println("\nEnter 1: to add a House");
		System.out.println("Enter 2: to add an Apartment");
		System.out.println("Enter 3: to display all House records");
		System.out.println("Enter 4: to display all Apartment records");
		System.out.println("Enter 5: to update House records");
		System.out.println("Enter 6: to update Apartment records");
		System.out.println("Enter 7: to Quit");
		System.out.print("Enter your choice: ");

		int res = sc.nextInt();

		return res;

	}
//this method takes the user input for data fields  of residence class
	public static void takeResidentialFields(){

		Scanner sc = new Scanner(System.in);

		System.out.print("\nEnter bedrooms: ");
		bedrooms = sc.nextInt();
		System.out.print("Enter bathrooms: ");
		bathrooms = sc.nextInt();
		System.out.print("Established year: ");
		yearBuilt = sc.nextInt();
		System.out.print("Enter price: ");
		price = sc.nextDouble();
		System.out.print("Enter Area in sq. feet: ");
		squareFeet = sc.nextDouble();
		sc.nextLine();
		System.out.print("Enter Residential Address: ");
		address = sc.nextLine();

	}
//This method displays the menus of residence class
	public static void updateResidentialFields(){

		System.out.print("\nEnter 1: to update bedrooms");
		System.out.print("\nEnter 2: to update bathrooms");
		System.out.print("\nEnter 3: to update the Established year");
		System.out.print("\nEnter 4: to update price");
		System.out.print("\nEnter 5: to update sq. feet");
		System.out.print("\nEnter 6: to update the Residential Address");
	
	}

}