





1)This project includes all the classses and functionality that is mentioned in the question.
2)I have introduced more functionality so that all functionality could be used.
3)All the LOCs are properly Commented.
4)This code works properly on Eclipse IDE.

Below I am mentioning few concepts that may confuse you:

In the ManagementSystem.java class, data members are introduced with static keywords as main()
method access them and you can can't a non-static variables or methods from a static context.So, 
Both should be static.
