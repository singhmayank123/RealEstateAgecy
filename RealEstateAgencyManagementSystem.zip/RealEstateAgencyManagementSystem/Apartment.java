// Inheriting the data members and methods of abstract class Residence
public class Apartment extends Residence{
//data field accessible to this package only
	int unit, floor, parkingLotNumber;
//No-args constructor
	Apartment(){
		unit = 0;
		floor = 0;
		parkingLotNumber = 0;
	}
//Parameterized Constructor
	Apartment(int unit, int floor, int parkingLotNumber,int bedrooms,
		int bathrooms,int yearBuilt,double price,double squareFeet,String address){
		//overloading the super class constructor using super();
		super(bedrooms,bathrooms,price,squareFeet,yearBuilt,address);
		this.unit = unit;
		this.floor = floor;
		this.parkingLotNumber = parkingLotNumber;
	}
//Getters methods for all data fields to retrieve them
	int getUnit(){
		return unit;
	}

	int getFloor(){
		return floor;
	}
	int getParkingNumber(){
		return parkingLotNumber;
	}
//Setters methods to set all data fields
	void setUnit(int unit){
		this.unit = unit;
	}
	void setFLoor(int floor){
		this.floor = floor;
	}
	void setParkingNumber(int parkingLotNumber){
		this.parkingLotNumber = parkingLotNumber;
	}
//Method to return all the data fields as a string
	public String toString(){

		System.out.println(super.toString());
		double ca = commissionAmount();
        
        String apartmentInfo = "Total Units: "+unit+
        					   "\nTotal floors: "+floor+
        					   "\nparkingLotNumber:"+parkingLotNumber+
        					   "\nCommission Amount:" +ca;

        return apartmentInfo;

	}

	public double commissionAmount(){
/*Commission Amount evaluates by multiplying commission Percentage with price.
commission is 3 which is equivalent 0.03 as 3/100 */
		/*@Override*/
		double commission_amount = price*0.03; 
		return commission_amount;
	}
}
