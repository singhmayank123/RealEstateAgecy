
//Created an abstract class that can't be instantiated 
public abstract class Residence{
//Data members that is acccessible to the current package only
	int bedrooms;
	int bathrooms;
	double price;
	double squareFeet;
	int yearBuilt;
	String address;
//No-args Constructor which invokes automatically when an instance is created for this class
	Residence(){
		bedrooms = 0;
		bathrooms = 0;
		price = 0.0;
		squareFeet = 0.0;
		yearBuilt = 2020;
		address = "XYZ location";
	}
//Parameterized Constructos which invokes when called explicitly
	Residence(int bedrooms,int bathrooms,double price,double squareFeet,int yearBuilt,String address){
//This keyword is used to indicate that these data members are initialized for the current object	
		this.bedrooms = bedrooms;
		this.bathrooms = bathrooms;
		this.price = price;
		this.squareFeet = squareFeet;
		this.yearBuilt = yearBuilt;
		this.address = address;
	}
//Getters methods for all data fields to retrieve them
	int getBedrooms(){
		return bedrooms;
	}
	int getBathrooms(){
		return bathrooms;
	}
	double getPrice(){
		return price;
	}
	double getSquareFeet(){
		return squareFeet;
	}
	int getYearBuilt(){
		return yearBuilt;
	}
	String getAddress(){
		return address;
	}
//Setters methods to set all data fields
	void setBedrooms(int bedrooms){
		this.bedrooms = bedrooms;
	}
	void setBathrooms(int bathrooms){
		this.bedrooms = bedrooms;
	}
	void setPrice(double price){
		this.price = price;
	}
	void setSquareFeet(double squareFeet){
		this.squareFeet = squareFeet;
	}
	void setYearBuilt(int yearBuilt){
		this.yearBuilt = yearBuilt;
	}
	void setAddress(String address){
		this.address = address;
	}
//Method to find commission for a customer
	public double commissionAmount(){
/*Commission Amount evaluates by multiplying commission Percentage with price.
Since commission percentage is 2 which is equivalent 0.02 as 2/100 */
		double commission_amount = price*0.02; 
		return commission_amount;
	}
//Method to return all the data fields as a string
	public String toString(){
		String residenceInfo = "\nTotal Bedrooms: "+bedrooms+
		             "\nTotal Bathrooms: "+bathrooms+
		             "\nPrice : "+price+
		             "\nSquare Feets : "+squareFeet+
		             "\nBuilt Year: "+yearBuilt+
		             "\nResidence Address: "+address;

		return residenceInfo;
	}
}
