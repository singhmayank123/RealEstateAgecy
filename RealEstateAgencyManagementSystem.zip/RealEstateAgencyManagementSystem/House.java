// House class inheriting the data members and methods of Residence Class
class House extends Residence{
	//data fields which is accessible to this package only
	int garage,stories; //declaring integer variables
	boolean isBasement, isBackyard; //declaring boolean variables 
//No-args Constructors
	House(){
		garage = 0;
		stories = 0;
		isBasement = false;
		isBackyard = false;
	}
//Parameterized Constructors
	House(int garage, int stories, Boolean isBasement, Boolean isBackyard,int bedrooms,
		int bathrooms,int yearBuilt,double price, double squareFeet, String address){

	//overloading the super class constructor using super();
		super(bedrooms,bathrooms,price,squareFeet,yearBuilt,address);

		this.garage = garage;
		this.stories = stories;
		this.isBasement = isBasement;
		this.isBackyard = isBackyard;

	}
//Getters methods for all data fields to retrieve them
	public int getGarage(){
		return garage;
	}
	public int getStories(){
		return stories;
	}
	public boolean checkBasement(){
		return isBasement;
	}
	public boolean checkBackyard(){
		return isBackyard;
	}
//Setters methods to set all data fields
	public void setGarage(int garage){
		this.garage = garage;
	}
	public void setStories(int stories){
		this.stories = stories;
	}
	public void setBasement(boolean isBasement){
		this.isBasement = isBasement;
	}
	public void setBackyard(boolean isBackyard){
		this.isBackyard = isBackyard;
	}
//Method to return all the data fields as a string
	public String toString(){

		System.out.println(super.toString());

		double ca = commissionAmount();

		String houseInfo = "Total Garage: "+garage+
						   "\nTotal stories: "+stories+
						   "\nBasement: "+isBasement+
						   "\nBackYard: "+isBackyard+
						   "\nCommission Amount: "+ca;
		return houseInfo;
	}

	public double commissionAmount(){
/*Commission Amount evaluates by multiplying commission Percentage with price.
Since commission is 3.5% which is equivalent 0.035 as 3.5/100 */
		/*@Override*/
		double commission_amount = price*0.035; 
		return commission_amount;
	}

}
